package com.meongdroid.aplikasipahlawanislamindonesia

data class Hero (
    var name : String = "",
    var biography : String = "",
    var country : String = "",
    var photo : String = ""
)



